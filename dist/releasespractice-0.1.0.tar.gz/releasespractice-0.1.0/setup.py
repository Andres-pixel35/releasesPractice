from setuptools import setup, find_packages

setup(
    name="releasesPractice",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Andres Rios",                         # Tu nombre
    author_email="riosandres294@gmail.com",                 # Tu correo electrónico
    url="https://github.com/Andres-pixel35/releasesPractice.git",     # URL del proyecto
)